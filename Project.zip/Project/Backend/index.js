const express = require('express');
const app = express();
const path = require('path');
const methodOverride = require('method-override');
const cors = require('cors');
require('dotenv').config();

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'public', 'views'));

// Middleware
app.use(express.static(path.join(__dirname, 'public'))); // Assuming static assets are inside 'public'
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(cors());  // Enable CORS for all routes

// Import routes
const userRoutes = require('./public/Routes/UserRoute');
const booking = require('./public/Routes/BookingRoute');
const { DbConnection } = require('./public/Config/Db');

// Connect to DB
DbConnection();

// Register routes
app.use('/User/', userRoutes);  // Routes are now prefixed with "/"
app.use('/booking/', booking);  // Routes are now prefixed with "/"

// Set the port and start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
