const Booking = require('../model/Booking'); // Make sure you import your Booking model

const nodemailer = require('nodemailer');// Assuming you have a Booking model

const createBooking = async (req, res) => {
  try {
    const { name, email, dateTime, numberOfPeople, specialRequest } = req.body;

    // Validation: Check if the required fields are provided
    if (!name || !email || !dateTime || !numberOfPeople) {
      return res.status(400).json({ error: 'Name, Email, Date & Time, and Number of People are required.' });
    }

    // Create a new booking
    const booking = new Booking({
      name,
      email,
      dateTime: new Date(dateTime),
      numberOfPeople,
      specialRequest,
    });

    // Save the booking to the database
    const savedBooking = await booking.save();

    // Set up the transporter using environment variables
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",  // Use Gmail's SMTP server
      port: 587,               // SMTP port for Gmail
      secure: false,           // Set to true for port 465, false for others
      auth: {
        user: process.env.EMAIL_USER,  // Using the email from environment variable
        pass: process.env.EMAIL_PASS,  // Using the password from environment variable
      },
    });

    // Email subject dynamically created
    const subject = `Booking Confirmation for ${name} on ${dateTime}`;

    // Email body content
    const textContent = `Dear ${name},\n\nThank you for your booking!\n\nYour table for ${numberOfPeople} people is confirmed for ${dateTime}.\n\nSpecial Request: ${specialRequest ? specialRequest : 'None'}.\n\nBest regards,\nRestaurant Team`;
    const htmlContent = `<b>Dear ${name},</b><br><br>Thank you for your booking!<br><br>Your table for ${numberOfPeople} people is confirmed for ${dateTime}.<br><br>Special Request: ${specialRequest ? specialRequest : 'None'}.<br><br>Best regards,<br>Restaurant Team`;

    // Sending email to the user with booking confirmation
    const info = await transporter.sendMail({
      from: `"Restaurant Team" <${process.env.EMAIL_USER}>`,  // Sender's email
      to: email,  // Recipient's email (user's email)
      subject: subject,  // Dynamic subject
      text: textContent,  // Plain text body
      html: htmlContent,  // HTML body
    });

    console.log('Email sent: ' + info.response);

    // Respond with success message and booking details
    res.status(201).json({
      message: 'Booking created successfully!',
      booking: savedBooking,
    });

  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


// Get All Bookings (GET)
const getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find(); // Get all bookings from the database
    res.status(200).json(bookings);
  } catch (error) {
    console.error('Error fetching bookings:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get Single Booking by ID (GET)
const getBookingById = async (req, res) => {
  try {
    const { bookingId } = req.params;

    const booking = await Booking.findById(bookingId);

    if (!booking) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    res.status(200).json(booking);
  } catch (error) {
    console.error('Error fetching booking:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update Booking (PUT)
const updateBookingbyid = async (req, res) => {
  try {
    const { bookingId } = req.params;
    const { name, email, dateTime, numberOfPeople, specialRequest } = req.body;

    const updatedBooking = await Booking.findByIdAndUpdate(
      bookingId,
      {
        name,
        email,
        dateTime: new Date(dateTime),
        numberOfPeople,
        specialReques,
      },
      { new: true } // Return the updated booking
    );

    if (!updatedBooking) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    res.status(200).json({
      message: 'Booking updated successfully!',
      booking: updatedBooking,
    });
  } catch (error) {
    console.error('Error updating booking:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Delete Booking (DELETE)
const deleteBooking = async (req, res) => {
  try {
    const { bookingId } = req.params;

    const deletedBooking = await Booking.findByIdAndDelete(bookingId);

    if (!deletedBooking) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    res.status(200).json({
      message: 'Booking deleted successfully!',
      booking: deletedBooking,
    });
  } catch (error) {
    console.error('Error deleting booking:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Exporting the functions for use in routes
module.exports = {
  createBooking,
  getAllBookings,
  getBookingById,
  updateBookingbyid,
  deleteBooking,
};
