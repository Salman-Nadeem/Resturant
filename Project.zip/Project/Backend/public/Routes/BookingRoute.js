const express = require('express');
const router = express.Router();
const bookingController = require('../controller/BookingController'); // Path to your bookingController
const {getAllBookings ,createBooking,getBookingById,updateBookingbyid,deleteBooking}  = require('../controller/BookingController')
// Create a new booking (POST) and Get all bookings (GET)
router.route('/')
  .get(getAllBookings)  // Get all bookings
  .post(createBooking); // Create a new booking

// Get a single booking by ID (GET), Update a booking by ID (PUT), and Delete a booking by ID (DELETE)
router.route('/:bookingId')
  .get(getBookingById)   // Get a single booking by ID
  .put(updateBookingbyid)    // Update booking by ID
  .delete(deleteBooking); // Delete booking by ID

module.exports = router;
