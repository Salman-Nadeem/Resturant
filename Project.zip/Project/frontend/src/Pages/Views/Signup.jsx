import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Login from './Login';
import { useNavigate } from 'react-router-dom'; // Importing useNavigate hook for navigation
import about1 from '../../img/about-1.jpg';
import "../../css/style.css";

const Registration = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
  });

  const [loading, setLoading] = useState(false);  // To manage the loading state
  const [error, setError] = useState(''); // To handle error messages
  const [successMessage, setSuccessMessage] = useState(''); // To handle success messages

  const navigate = useNavigate(); // Hook to navigate to the login page

  // Function to send data using axios on form submit
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent the default form submission

    // Disable the submit button and show loading state
    setLoading(true);
    setError(''); // Clear any previous error messages
    setSuccessMessage(''); // Clear any previous success messages

    try {
      // Sending form data to the backend
      const response = await axios.post('http://localhost:5000/User/', formData);

      console.log(response.data);  // Log the response from the server

      // Reset form data after successful registration
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
      });

      // Set success message and navigate to the login page after a delay
      setSuccessMessage('User successfully registered!');
      setTimeout(() => {
        navigate('/Login'); // Navigate to the login page after 2 seconds
      }, 1000); 

    } catch (error) {
      console.error(error);
      setError('There was an error with registration. Please try again.');
    } finally {
      setLoading(false); // Enable the submit button again after the request completes
    }
  };

  return (
    <section className="p-5 p-md-6 p-lg-7">
      <div className="container">
        <div className="card border-0 shadow-lg rounded-5">
          <div className="row g-0">
            {/* Left Section: Image and Description */}
            <div className="col-12 col-md-6 bg-gradient text-white rounded-start d-flex align-items-center justify-content-center">
              <div className="text-center p-5">
                <img
                  className="img-fluid rounded mb-4"
                  loading="lazy"
                  src={about1}
                  alt="Digital Products"
                  style={{ maxWidth: '100%', height: 'auto', objectFit: 'cover' }}
                />
                <h2 className="display-4 mb-4">Stand out with exceptional digital products</h2>
                <p className="lead mb-5">We create, design, and innovate across every digital platform to elevate your brand.</p>
              </div>
            </div>

            {/* Right Section: Registration Form */}
            <div className="col-12 col-md-6">
              <div className="card-body p-4 p-md-5">
                <h2 className="h3 mb-4">Create an Account</h2>
                <p className="text-muted fs-5 mb-4">Join our platform and start building your digital future.</p>

                {/* Show error message if exists */}
                {error && <div className="alert alert-danger">{error}</div>}

                {/* Show success message if exists */}
                {successMessage && <div className="alert alert-success">{successMessage}</div>}

                <form onSubmit={handleSubmit}>
                  <div className="row gy-4">
                    {/* First Name Field */}
                    <div className="col-12">
                      <label htmlFor="firstName" className="form-label">First Name <span className="text-danger">*</span></label>
                      <input
                        type="text"
                        className="form-control shadow-sm"
                        name="firstName"
                        id="firstName"
                        placeholder="John"
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        required
                      />
                    </div>

                    {/* Last Name Field */}
                    <div className="col-12">
                      <label htmlFor="lastName" className="form-label">Last Name <span className="text-danger">*</span></label>
                      <input
                        type="text"
                        className="form-control shadow-sm"
                        name="lastName"
                        id="lastName"
                        placeholder="Doe"
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        required
                      />
                    </div>

                    {/* Email Field */}
                    <div className="col-12">
                      <label htmlFor="email" className="form-label">Email Address <span className="text-danger">*</span></label>
                      <input
                        type="email"
                        className="form-control shadow-sm"
                        name="email"
                        id="email"
                        placeholder="name@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                      />
                    </div>

                    {/* Password Field */}
                    <div className="col-12">
                      <label htmlFor="password" className="form-label">Password <span className="text-danger">*</span></label>
                      <input
                        type="password"
                        className="form-control shadow-sm"
                        name="password"
                        id="password"
                        placeholder="******"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        required
                      />
                    </div>

                    {/* Submit Button */}
                    <div className="col-12">
                      <button className="btn btn-primary btn-lg shadow-lg hover-shadow" type="submit" disabled={loading}>
                        {loading ? 'Registering...' : 'Sign Up'}
                      </button>
                    </div>
                  </div>
                </form>

                {/* Login Link */}
             
<div className="row mt-4">
  <div className="col-12 text-center">
    <p className="text-muted">Already have an account? <Link to="/Login" className="link-primary">Sign in</Link></p>
  </div>
</div>

                {/* Social Media Sign Up */}
                <div className="row mt-4">
                  <div className="col-12 text-center">
                    <p className="text-muted">Or sign up with</p>
                    <div className="d-flex justify-content-center gap-3">
                      {/* Google Sign Up */}
                      <a href="#!" className="btn btn-outline-danger btn-lg rounded-circle shadow-lg hover-shadow">
                        <i className="bi bi-google"></i>
                      </a>
                      {/* Facebook Sign Up */}
                      <a href="#!" className="btn btn-outline-primary btn-lg rounded-circle shadow-lg hover-shadow">
                        <i className="bi bi-facebook"></i>
                      </a>
                      {/* Twitter Sign Up */}
                      <a href="#!" className="btn btn-outline-info btn-lg rounded-circle shadow-lg hover-shadow">
                        <i className="bi bi-twitter"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Registration;
