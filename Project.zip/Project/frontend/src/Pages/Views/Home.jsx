import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'; // React Router ke liye
import Navbar from '../../Component/Navbar';
import hero from '../../img/hero.png';

const Home = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate(); // Redirect karne ke liye

  useEffect(() => {
    // Check if there's data in localStorage
    const userData = localStorage.getItem('user'); // Yahan 'user' wo key hai jo aap store karte hain
    if (userData) {
      setIsLoggedIn(true);
    } else {
      navigate('/'); // Agar data nahi hai to login page pe redirect karein
    }
  }, [navigate]); // useEffect ko run karte waqt navigate ko track karein

  if (!isLoggedIn) {
    return null; // Agar user logged in nahi hai to kuch bhi render nahi karein
  }

  return (
    <>
      <Navbar />
      {/* Hero Section with Overlay */}
      <div className="hero-header position-relative p-0" style={{ width: '100%' }}>
        <div className="hero-overlay position-absolute w-100 h-100 top-0 start-0 bg-dark opacity-50 z-index-2"></div>
        
        {/* Hero Content */}
        <div className="container my-5 py-5 position-relative z-index-1">
          <div className="row align-items-center g-5">
            <div className="col-lg-6 text-center text-lg-start">
              <h1 className="display-3 text-white animated slideInLeft">
                Enjoy Our<br />Delicious Meal
              </h1>
              <p className="text-white animated slideInLeft mb-4 pb-2">
                Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet.
              </p>
              <a href="/booking" className="btn btn-primary py-sm-3 px-sm-5 me-3 animated slideInLeft">
                Book A Table
              </a>
            </div>
            <div className="col-lg-6 text-center text-lg-end overflow-hidden">
              <img className="img-fluid" src={hero} alt="Hero" />
            </div>
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div className="container-xxl py-5">
        <div className="container">
          <div className="row g-4">
            <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
              <div className="service-item rounded pt-3">
                <div className="p-4">
                  <i className="fa fa-3x fa-user-tie text-primary mb-4"></i>
                  <h5>Master Chefs</h5>
                  <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam</p>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
              <div className="service-item rounded pt-3">
                <div className="p-4">
                  <i className="fa fa-3x fa-utensils text-primary mb-4"></i>
                  <h5>Quality Food</h5>
                  <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam</p>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
              <div className="service-item rounded pt-3">
                <div className="p-4">
                  <i className="fa fa-3x fa-cart-plus text-primary mb-4"></i>
                  <h5>Online Order</h5>
                  <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam</p>
                </div>
              </div>
            </div>

            <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
              <div className="service-item rounded pt-3">
                <div className="p-4">
                  <i className="fa fa-3x fa-headset text-primary mb-4"></i>
                  <h5>24/7 Service</h5>
                  <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
