import React, { useState } from 'react';
import menu_one from '../../img/menu-1.jpg'
import Footer from '../../Component/Footer';

const Menu = () => {
  const [activeTab, setActiveTab] = useState('tab-1'); // State to handle active tab

  const menuItems = [
    { name: "Chicken Burger", price: "$115", description: "Ipsum ipsum clita erat amet dolor justo diam"},
    { name: "Chicken Burger", price: "$115", description: "Ipsum ipsum clita erat amet dolor justo diam" },
    { name: "Chicken Burger", price: "$115", description: "Ipsum ipsum clita erat amet dolor justo diam" },
    { name: "Chicken Burger", price: "$115", description: "Ipsum ipsum clita erat amet dolor justo diam" },
    { name: "Chicken Burger", price: "$115", description: "Ipsum ipsum clita erat amet dolor justo diam" },
    { name: "Chicken Burger", price: "$115", description: "Ipsum ipsum clita erat amet dolor justo diam" },
    { name: "Chicken Burger", price: "$115", description: "Ipsum ipsum clita erat amet dolor justo diam" },
    { name: "Chicken Burger", price: "$115", description: "Ipsum ipsum clita erat amet dolor justo diam" }
  ];

  // Function to render menu items
  const renderMenuItems = () => {
    return menuItems.map((item, index) => (
      <div key={index} className="col-lg-6">
        <div className="d-flex align-items-center">
          <img className="flex-shrink-0 img-fluid rounded" src={menu_one} alt="" style={{ width: '80px' }} />
          <div className="w-100 d-flex flex-column text-start ps-4">
            <h5 className="d-flex justify-content-between border-bottom pb-2">
              <span>{item.name}</span>
              <span className="text-primary">{item.price}</span>
            </h5>
            <small className="fst-italic">{item.description}</small>
          </div>
        </div>
      </div>
    ));
  };

  return (
    <div>
      {/* Navbar & Hero Start */}
      <div className="container-xxl position-relative p-0" >
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top px-4 px-lg-5 py-3 py-lg-0">
          <a href="/home" className="navbar-brand p-0">
            <h1 className="text-primary m-0"><i className="fa fa-utensils me-3"></i>Restoran</h1>
          </a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span className="fa fa-bars"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarCollapse">
            <div className="navbar-nav ms-auto py-0 pe-4">
              <a href="/home" className="nav-item nav-link">Home</a>
              <a href="/about" className="nav-item nav-link">About</a>
              <a href="/service" className="nav-item nav-link">Service</a>
              <a href="/menu" className="nav-item nav-link active">Menu</a>
        
              <a href="/contact" className="nav-item nav-link">Contact</a>
            </div>
            <a href="/booking" className="btn btn-primary py-2 px-4">Book A Table</a>
          </div>
        </nav>

        <div className="container-xxl py-5 bg-dark hero-header mb-5" >
          <div className="container text-center my-5 pt-5 pb-4">
            <h1 className="display-3 text-white mb-3 animated slideInDown">Food Menu</h1>
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb justify-content-center text-uppercase">
                <li className="breadcrumb-item"><a href="/">Home</a></li>
                <li className="breadcrumb-item"><a href="#">Pages</a></li>
                <li className="breadcrumb-item text-white active" aria-current="page">Menu</li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
      {/* Navbar & Hero End */}

      {/* Menu Section Start */}
      <div className="container-xxl py-5">
        <div className="container">
          <div className="text-center">
            <h5 className="section-title ff-secondary text-center text-primary fw-normal">Food Menu</h5>
            <h1 className="mb-5">Most Popular Items</h1>
          </div>
          <div className="tab-class text-center">
            <ul className="nav nav-pills d-inline-flex justify-content-center border-bottom mb-5">
              <li className="nav-item">
                <a
                  className={`d-flex align-items-center text-start mx-3 ms-0 pb-3 ${activeTab === 'tab-1' ? 'active' : ''}`}
                  onClick={() => setActiveTab('tab-1')}
                >
                  <i className="fa fa-coffee fa-2x text-primary"></i>
                  <div className="ps-3">
                    <small className="text-body">Popular</small>
                    <h6 className="mt-n1 mb-0">Breakfast</h6>
                  </div>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`d-flex align-items-center text-start mx-3 pb-3 ${activeTab === 'tab-2' ? 'active' : ''}`}
                  onClick={() => setActiveTab('tab-2')}
                >
                  <i className="fa fa-hamburger fa-2x text-primary"></i>
                  <div className="ps-3">
                    <small className="text-body">Special</small>
                    <h6 className="mt-n1 mb-0">Lunch</h6>
                  </div>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`d-flex align-items-center text-start mx-3 me-0 pb-3 ${activeTab === 'tab-3' ? 'active' : ''}`}
                  onClick={() => setActiveTab('tab-3')}
                >
                  <i className="fa fa-utensils fa-2x text-primary"></i>
                  <div className="ps-3">
                    <small className="text-body">Lovely</small>
                    <h6 className="mt-n1 mb-0">Dinner</h6>
                  </div>
                </a>
              </li>
            </ul>

            <div className="tab-content">
              <div id="tab-1" className={`tab-pane fade show ${activeTab === 'tab-1' ? 'active' : ''}`}>
                <div className="row g-4">{renderMenuItems()}</div>
              </div>
              <div id="tab-2" className={`tab-pane fade show ${activeTab === 'tab-2' ? 'active' : ''}`}>
                <div className="row g-4">{renderMenuItems()}</div>
              </div>
              <div id="tab-3" className={`tab-pane fade show ${activeTab === 'tab-3' ? 'active' : ''}`}>
                <div className="row g-4">{renderMenuItems()}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Menu Section End */}
      <Footer/>
    </div>
  );
};

export default Menu;
