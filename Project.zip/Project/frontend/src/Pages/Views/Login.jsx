import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import hero from '../../img/about-2.jpg'; // Image for login page
import "../../css/style.css";

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const [loading, setLoading] = useState(false); // To manage loading state
  const [error, setError] = useState(''); // To handle error messages
  const [successMessage, setSuccessMessage] = useState(''); // To handle success messages

  const navigate = useNavigate(); // Hook to navigate to another page

  // Check if user is already logged in (from localStorage)
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user && user.userName && user.userRole) {
      navigate('/home'); // If user is already logged in, redirect to home
    }
  }, [navigate]);

  // Handle form submit
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent the default form submission

    setLoading(true);
    setError(''); // Clear previous errors
    setSuccessMessage(''); // Clear previous success messages

    try {
      const response = await axios.post('http://localhost:5000/User/login', formData);

      if (response.data.message === 'Login successful') {
        setSuccessMessage('Login successful!');
        
        // Store user data in localStorage as a single object
        localStorage.setItem('user', JSON.stringify({
          userName: response.data.userName,
          userRole: response.data.userRole
        }));

        // Navigate to home page after a delay
        setTimeout(() => {
          navigate('/home');
        }, 1000); // Adding a slight delay
      }

    } catch (error) {
      setError(error.response ? error.response.data.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false); // Re-enable the submit button
    }
  };

  return (
    <section className="p-5 p-md-6 p-lg-7">
      <div className="container">
        <div className="card border-0 shadow-lg rounded-5">
          <div className="row g-0">
            {/* Left Section: Image and Description */}
            <div className="col-12 col-md-6 bg-gradient text-white rounded-start d-flex align-items-center justify-content-center">
              <div className="text-center p-5">
                <img
                  className="img-fluid rounded mb-4"
                  loading="lazy"
                  src={hero}
                  alt="Login Image"
                  style={{ maxWidth: '100%', height: 'auto', objectFit: 'cover' }}
                />
                <h2 className="display-4 mb-4">Welcome Back</h2>
                <p className="lead mb-5">Log in to your account and continue where you left off.</p>
              </div>
            </div>

            {/* Right Section: Login Form */}
            <div className="col-12 col-md-6">
              <div className="card-body p-4 p-md-5">
                <h2 className="h3 mb-4">Login</h2>
                <p className="text-muted fs-5 mb-4">Enter your credentials to access your account.</p>

                {/* Show error message if exists */}
                {error && <div className="alert alert-danger">{error}</div>}

                {/* Show success message if exists */}
                {successMessage && <div className="alert alert-success">{successMessage}</div>}

                <form onSubmit={handleSubmit}>
                  <div className="row gy-4">
                    {/* Email Field */}
                    <div className="col-12">
                      <label htmlFor="email" className="form-label">Email Address <span className="text-danger">*</span></label>
                      <input
                        type="email"
                        className="form-control shadow-sm"
                        name="email"
                        id="email"
                        placeholder="name@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                      />
                    </div>

                    {/* Password Field */}
                    <div className="col-12">
                      <label htmlFor="password" className="form-label">Password <span className="text-danger">*</span></label>
                      <input
                        type="password"
                        className="form-control shadow-sm"
                        name="password"
                        id="password"
                        placeholder="******"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        required
                      />
                    </div>

                    {/* Submit Button */}
                    <div className="col-12">
                      <button className="btn btn-primary btn-lg shadow-lg hover-shadow" type="submit" disabled={loading}>
                        {loading ? 'Logging In...' : 'Log In'}
                      </button>
                    </div>
                  </div>
                </form>

                {/* Registration Link */}
                <div className="row mt-4">
                  <div className="col-12 text-center">
                    <p className="text-muted">Don't have an account? <Link to="/registration" className="link-primary">Sign up</Link></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Login;
