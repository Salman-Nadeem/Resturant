import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../css/bootstrap.min.css';  // Import Bootstrap CSS

const Navbar = () => {
  // Initialize the navigate function to redirect after logout
  const navigate = useNavigate();

  // Handle logout
  const handleLogout = () => {
    // Clear local storage
    localStorage.clear();

    // Redirect to the homepage or login page after logout (you can adjust the URL)
    navigate('/'); 
  };

  return (
    <div>
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top w-100 z-index-3">
        <div className="container">
          <Link to="/" className="navbar-brand p-0">
            <h1 className="text-primary m-0">
              <i className="fa fa-utensils me-3"></i>Restoran
            </h1>
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
            aria-controls="navbarCollapse"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="fa fa-bars"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarCollapse">
            <div className="navbar-nav ms-auto py-0 pe-4">
              <Link to="/home" className="nav-item nav-link active">Home</Link>
              <Link to="/about" className="nav-item nav-link">About</Link>
              <Link to="/service" className="nav-item nav-link">Service</Link>
              <Link to="/menu" className="nav-item nav-link">Menu</Link>
              <Link to="/contact" className="nav-item nav-link">Contact</Link>
            </div>
            {/* Add Logout Button */}
            <button className="btn btn-danger py-2 px-4" onClick={handleLogout}>
              Logout
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
