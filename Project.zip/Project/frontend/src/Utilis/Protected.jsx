import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Get the 'user' object from localStorage
    const user = JSON.parse(localStorage.getItem('user'));

    // Check if the user object exists and has the necessary properties
    if (user && user.userName && user.userRole) {
      setIsLoggedIn(true);
    }
  }, []); // Run only once when the component mounts

  // If the user is not logged in, redirect to the login page
  if (!isLoggedIn) {
    return <Navigate to="/login" />; // Redirect to login page if not logged in
  }

  return children; // Render child components if logged in
};

export default ProtectedRoute;
